#include "lab02.h"

#include <xc.h>
#include <p33Fxxxx.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL
#include <libpic30.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

#define FCY_EXT 32768

volatile unsigned long tSeconds = 0;
volatile unsigned long tMilliseconds = 0;

void initialize_timer()
{
    
    // Enable RTC Oscillator -> this effectively does OSCCONbits.LPOSCEN = 1
    // but the OSCCON register is lock protected. That means you would have to 
    // write a specific sequence of numbers to the register OSCCONL. After that 
    // the write access to OSCCONL will be enabled for one instruction cycle.
    // The function __builtin_write_OSCCONL(val) does the unlocking sequence and
    // afterwards writes the value val to that register. (OSCCONL represents the
    // lower 8 bits of the register OSCCON)
    __builtin_write_OSCCONL(OSCCONL | 2);
    // Disable the Timers
    CLEARBIT(T1CONbits.TON);
    CLEARBIT(T2CONbits.TON);
    CLEARBIT(T3CONbits.TON);

    T2CONbits.T32 = 0;  // T2 and T3 serve as two independent 16-bit timers
    IEC0bits.T3IE = 0;  // Configure TIM3 for count reading only, with interrupts disabled
    IFS0bits.T3IF = 0;
    // Set Prescaler
    T1CONbits.TCKPS = 0b11;
    T2CONbits.TCKPS = 0b11;
    T3CONbits.TCKPS = 0b00;
    // Set Clock Source
    T1CONbits.TCS = 1;
    CLEARBIT(T2CONbits.TCS);
    CLEARBIT(T3CONbits.TCS);
    // Set Gated Timer Mode -> don't use gating
    CLEARBIT(T1CONbits.TGATE);
    CLEARBIT(T2CONbits.TGATE);
    CLEARBIT(T3CONbits.TGATE);
    // T1: Set External Clock Input Synchronization -> no sync
    T1CONbits.TSYNC = 0;
    // Load Timer Periods
    PR1 = 127;
    PR2 = 99;
    PR3 = 65535;
    // Reset Timer Values
    TMR1 = 0x00;
    TMR2 = 0x00;
    TMR3 = 0x00;
    // Set Interrupt Priority
    IPC0bits.T1IP = 0x01;
    IPC1bits.T2IP = 0x01;
    // Clear Interrupt Flags
    CLEARBIT(IFS0bits.T1IF);
    CLEARBIT(IFS0bits.T2IF);
    // Enable Interrupts
    SETBIT(IEC0bits.T1IE);
    SETBIT(IEC0bits.T2IE);
    // Enable the Timers
    SETBIT(T1CONbits.TON);
    SETBIT(T2CONbits.TON);
}

void timer_loop()
{
    // print assignment information
    unsigned int loopCount = 0; //record the cycle times

    unsigned long secondsCopy;
    unsigned long minutes;
    unsigned int seconds;
    unsigned int milliseconds;
    unsigned int timer3value;
    unsigned int overflow;
    unsigned long timeScaled;
    unsigned int msWhole;
    unsigned int msFraction;
    
    lcd_printf("Lab02: Int & Timer");
    lcd_locate(0, 1);
    lcd_printf("Group: 11");
    
    TMR3 = 0;
    IFS0bits.T3IF = 0;
    SETBIT(T3CONbits.TON);
   while (TRUE)
{
    loopCount++;
    
    if (loopCount == 2000)
    {
        // Finish the measurement before handling the LED and display translation
        CLEARBIT(T3CONbits.TON);
        timer3value = TMR3;
        overflow = IFS0bits.T3IF;

        TOGGLELED(LED3_PORT);

            
        IEC0bits.T1IE = 0;
        IEC0bits.T2IE = 0;

        secondsCopy = tSeconds;
        milliseconds = (unsigned int)tMilliseconds;

        IEC0bits.T1IE = 1;
        IEC0bits.T2IE = 1;

        // Convert total seconds into minutes and seconds
        minutes = secondsCopy / 60UL;
        seconds = (unsigned int)(secondsCopy % 60UL);
        
        // Display at a fixed location
        lcd_locate(0, 2);
        lcd_printf("Up: %02lu:%02u.%03u",
                   minutes, seconds, milliseconds);
        
                // Display the raw Timer3 count
        lcd_locate(0, 3);
        lcd_printf("T3 count: %5u     ", timer3value);// Display the measured time
        
        lcd_locate(0, 4);

        if (overflow)
        {
            lcd_printf("T3: overflow        ");
        }
        else
        {
            timeScaled =
                ((unsigned long)timer3value * 10000UL + 6400UL)
                / 12800UL;

            msWhole = (unsigned int)(timeScaled / 10000UL);
            msFraction = (unsigned int)(timeScaled % 10000UL);

            lcd_printf("T3: %u.%04u ms      ", msWhole, msFraction);
        }
        
        loopCount = 0;
        TMR3 = 0x00;
        CLEARBIT(IFS0bits.T3IF);
        SETBIT(T3CONbits.TON);
    }
}
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T1Interrupt(void)
{ // invoked every ??
    TOGGLELED(LED2_PORT);

    tSeconds += 1;
    tMilliseconds = 0;

    IFS0bits.T1IF = 0;
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T2Interrupt(void)
{
    TOGGLELED(LED1_PORT);

    if (tMilliseconds < 998)
    {
        tMilliseconds += 2;
    }

    IFS0bits.T2IF = 0;
}
